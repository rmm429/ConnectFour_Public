public class Player {

    String Name;
    String Color;

    public Player()
    {
        Name = "";
        Color = "Red";
    }

    public String getPlayerName(){
        return Name;
    }

    public void setPlayerName(String name){
        Name = name;
    }

    public String getColor(){
        return Color;
    }

    public void setColor(String color)
    {
        Color = color;
    }

    public void insertGamePiece(char color, int column, Board gameBoard){
        for(int i =0;i<6;i++)
        {
            if(gameBoard.GetLocation(column,i) == 0)
            {
                gameBoard.setLocation(column,i,color);
            }
        }

    }

}
