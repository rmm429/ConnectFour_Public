public class BoardPieces {
    int column;
    int row;
    char color;

    public BoardPieces()
    {

    }

    public int getColumn()
    {
        return column;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getRow() {
        return row;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public void setColor(char color) {
        this.color = color;
    }

    public char getColor() {
        return color;
    }
}
