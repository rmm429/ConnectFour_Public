import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class GamePanel extends JFrame {

    public final int ROWS = 6;
    public final int COLS = 7;

    public char currentPlayer = 'R';

    public static GamePanel gamePanel;
    public Game game;

    public static JMenuBar menuBar;
    public static JMenu menu;

    public static JPanel playerPanel;
    public static JPanel arrowsPanel;
    public static JPanel boardPanel;

    public JLabel curPlayer;

    public GridBagLayout boardLayout;
    public GridBagConstraints boardConstraints;

    public BufferedImage emptyImg = null;
    public BufferedImage redImg = null;
    public BufferedImage blueImg = null;
    //public static BufferedImage yellowImg = null;
    public BufferedImage arrowImg = null;

    public JButton[] arrowBtns = new JButton[COLS];
    public JLabel[][] piecesImgs = new JLabel[COLS][ROWS];

    void handleEvent (ActionEvent e) {

//        //DELETE LATER ---------
//        System.out.println("Current player: " + Character.toString(currentPlayer) + "\n");
//        // ----------------------

        String btnPressed = e.getActionCommand();

            switch (btnPressed) {

                case "0":
                    addPiece(currentPlayer, 0, 5);
                    break;
                case "1":
                    addPiece(currentPlayer, 1, 5);
                    break;
                case "2":
                    addPiece(currentPlayer, 2, 5);
                    break;
                case "3":
                    addPiece(currentPlayer, 3, 5);
                    break;
                case "4":
                    addPiece(currentPlayer, 4, 5);
                    break;
                case "5":
                    addPiece(currentPlayer, 5, 5);
                    break;
                case "6":
                    addPiece(currentPlayer, 6, 5);
                    break;
                default:
                    System.err.println("ERROR: Cannot determine button action (CODE BEHAVIOR ISSUE)");
                    System.exit(1);

            }

    }

    public void addBtns() {

        for (int i = 0; i < COLS; i++) {

            JButton btn = new JButton();

            btn.setIcon(new ImageIcon(arrowImg));
            btn.setBorder(BorderFactory.createEmptyBorder());
            btn.setContentAreaFilled(false);

            btn.setActionCommand("" + i);

            btn.addActionListener(e -> handleEvent(e));

            arrowBtns[i] = btn;

            arrowsPanel.add(arrowBtns[i]);

        }

    }

    public void addGB() {

        for(int row = 0; row < ROWS; row++) {

            boardConstraints.fill = GridBagConstraints.HORIZONTAL;

            for (int col = 0; col < COLS; col++ ) {

                JLabel piece = new JLabel();

                //int rowInv = Math.abs(row-ROWS)-1; // Use if end of 2D array should instead correlate with top of board

                piece.setIcon(new ImageIcon(emptyImg));
                piecesImgs[col][row] = piece;
                //piecesImgs[col][rowInv] = piece; // Use if end of 2D array should instead correlate with top of board

                boardConstraints.gridx = col;
                boardConstraints.gridy = row;
                boardPanel.add(piecesImgs[col][row], boardConstraints);
                //boardPanel.add(piecesImgs[col][rowInv], boardConstraints); // Use if end of 2D array should instead correlate with top of board

            }

        }

    }

    public void addPiece(char color, int col, int row) {

        if (game.isColumnFull(col) == false) {

            // Advances up the game board until an empty spot is reached to place the piece
            while (game.getLocationStatus(col, row) != 0) {
                row--;
            }

            if (color == 'R') {
                piecesImgs[col][row].setIcon(new ImageIcon(redImg));
            } else if (color == 'B') {
                piecesImgs[col][row].setIcon(new ImageIcon(blueImg));
            }

            game.addGamePiece(col, row, color);

            if (game.isColumnFull(col) == true) {
                arrowBtns[col].setEnabled(false);
            }

            if (game.GameOver() != 0)
            {
                declareWinner(game.GameOver());
            } else {
                switchPlayer();
            }

        }

    }

    public void switchPlayer() {

        currentPlayer = (currentPlayer == 'R') ? 'B' : 'R'; // Switch player
        curPlayer.setText( (curPlayer.getText().equals("Red's Turn") ) ? "Blue's Turn" : "Red's Turn"); // Switch player text

    }

    public void declareWinner(char winner) {

        String dialogMsg = "GAME OVER\n";

        if (Character.toString(winner).equals("R")) {
            dialogMsg += "Red is the winner!";
        } else if (Character.toString(winner).equals("B")) {
            dialogMsg += "Blue is the winner!";
        } else {
            System.err.println("ERROR: Cannot determine winner (CODE BEHAVIOR ISSUE)");
            System.exit(1);
        }

        JOptionPane.showMessageDialog(null, dialogMsg);

        System.exit(0);

    }

    public GamePanel() {

        game = new Game();

        playerPanel = new JPanel();
        arrowsPanel = new JPanel();
        boardPanel = new JPanel();

        try {
            emptyImg = ImageIO.read(getClass().getResource("/images/empty.png"));
            redImg = ImageIO.read(getClass().getResource("/images/red.png"));
            blueImg = ImageIO.read(getClass().getResource("/images/blue.png"));
            //yellowImg = ImageIO.read(getClass().getResource("/images/yellow.png"));
            arrowImg  = ImageIO.read(getClass().getResource("/images/arrow.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        playerPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        arrowsPanel.setLayout(new GridLayout(0, COLS, 4, 4));

        curPlayer = new JLabel("Red's Turn");
        curPlayer.setFont(new Font("Serif", Font.PLAIN, 30));
        playerPanel.add(curPlayer, BorderLayout.CENTER);

        boardLayout = new GridBagLayout();
        boardConstraints = new GridBagConstraints();
        boardConstraints.ipadx = 4;
        boardConstraints.ipady = 4;

        boardPanel.setLayout(boardLayout);
        boardPanel.setBackground(Color.YELLOW);

    }

    public static void main(String[] args) {

        JFrame frame = new JFrame("GamePanel");

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent){
                System.exit(0);
            }
        });

        JPanel window = new JPanel();

        BorderLayout borderLayout = new BorderLayout();
        borderLayout.setHgap(10);
        borderLayout.setVgap(10);

        window.setLayout(borderLayout);

        menuBar = new JMenuBar();
        menu = new JMenu("Menu");

        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(evt -> {
            System.exit(0);
        });

        menu.add(exitItem);
        menuBar.add(menu);
        frame.setJMenuBar(menuBar);

        gamePanel = new GamePanel();
        gamePanel.addBtns();
        gamePanel.addGB();

        window.add(playerPanel, BorderLayout.NORTH);
        window.add(arrowsPanel, BorderLayout.CENTER);
        window.add(boardPanel, BorderLayout.SOUTH);

        frame.getContentPane().add(window);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }


}
