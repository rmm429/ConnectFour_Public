public class Game {

    public Board gameBoard;

    public Game()
    {
        gameBoard = new Board();
    }

    public String TestOut() {
        return "SUCCESS";
    }

    public char GameOver(){
        char winner;
        winner=Diaganol();

        if(winner != 0)
        {
            return winner;
        }
        winner = Horizontal();
        if(winner != 0)
        {
            return winner;
        }
        winner = Vertical();
        if(winner != 0)
        {
            return winner;
        }
        return 0;
    }

    //Checks Diagonal Winner
    public char Diaganol(){

        //Check diaganol Right
        char check = 0; // Variable to hold the team color
        boolean winner=false;
        for(int i=0; i<4;i++){
            for(int j=0;j<3;j++)
            {
                check = gameBoard.GetLocation(i,j);
                if(check != 0)
                {
                    //check to see if next 3 are the same color
                    for(int k=1;k<4;k++)
                    {
                        if(gameBoard.GetLocation(i+k,j+k) != check)
                        {
                            winner=false;
                            break;
                        }
                        else
                        {
                            winner = true;
                        }
                    }
                    if(winner)
                    {
                        return check;
                    }
                }
            }
        }
        // Check for diagonal left
        for(int i=6; i>2;i--){
            for(int j=0;j<3;j++)
            {
                check = gameBoard.GetLocation(i,j);
                if(check != 0) {
                    for (int k = 1; k < 4; k++) {
                        if (gameBoard.GetLocation(i - k, j + k) != check) {
                            winner = false;
                            break;
                        } else {
                            winner = true;
                        }
                    }
                    if (winner) {
                        return check;
                    }
                }
            }
        }

        return 0;

    }

    // Check for horizontal four in a row
    public char Horizontal(){

        char check = 0;
        boolean winner=false;

        for(int i=0; i<5;i++){

            for(int j=0;j<6;j++) {

                check = gameBoard.GetLocation(i,j);

                if(check != 0) {

                    for (int k = 1; k < 4; k++) {

                        // Was previously checking columns that were out-of-bounds without this statement
                        if ( (i+k) < 7) { // Ensures that the current column being checked is in bounds

                            if (gameBoard.GetLocation(i+k, j) != check) {
                                winner = false;
                                break;
                            } else {
                                winner = true;
                            }

                        } else {
                            winner = false;
                            break;
                        }

                    }

                    if (winner) {
                        return check;
                    }

                }

            }

        }

        return 0;

    }

    //Check for Vertical four in a row
    public char Vertical(){

        char check = 0;
        boolean winner=false;

        for(int i=0; i<7;i++) {

            for(int j=0;j<4;j++) {

                check = gameBoard.GetLocation(i,j);

                if(check != 0) {

                    for (int k = 1; k < 4; k++) {

                        // Was previously checking rows that were out-of-bounds without this statement
                        if ( (j+k) < 6 ) { // Ensures that the current row being checked is in bounds

                            if (gameBoard.GetLocation(i, j + k) != check) {
                                winner = false;
                                break;
                            } else {
                                winner = true;
                            }

                        } else {
                            winner = false;
                            break;
                        }

                    }

                    if (winner) {
                        return check;
                    }

                }

            }

        }

        return 0;
    }

    public void addGamePiece(int col, int row, char color) {
        gameBoard.setLocation(col, row, color);
//        //DELETE LATER ---------
//        gameBoard.getBoard();
//        // ----------------------
    }

    public char getLocationStatus(int col, int row) {
        return gameBoard.GetLocation(col, row);
    }

    public boolean isColumnFull(int col) {
        return gameBoard.isColumnFull(col);
    }

}
