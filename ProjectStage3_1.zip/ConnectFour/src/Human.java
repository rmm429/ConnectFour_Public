public class Human {
}
